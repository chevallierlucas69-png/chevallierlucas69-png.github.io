param(
    [string]$NormalPlanFile,
    [string]$HighPerformanceGuid = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
)

$ErrorActionPreference = "SilentlyContinue"

function Restore-NormalPlan {
    $normalPlan = "381b4222-f694-41f0-9685-ff5bb260df2e"
    if ($NormalPlanFile -and (Test-Path -LiteralPath $NormalPlanFile)) {
        $savedPlan = (Get-Content -LiteralPath $NormalPlanFile -Raw).Trim()
        if ($savedPlan -match "^[0-9a-fA-F-]{36}$") { $normalPlan = $savedPlan }
    }
    powercfg /setactive $normalPlan | Out-Null
}

powercfg /setactive $HighPerformanceGuid | Out-Null
New-Item -Path "HKCU:\Software\Microsoft\GameBar" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Type DWord -Value 1

$initialDeadline = (Get-Date).AddMinutes(10)
$targetWasSeen = $false
$noTargetSince = $null

try {
    while ($true) {
        $targets = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
            $_.ProcessName -ieq "retrac" -or
            $_.ProcessName -like "FortniteClient-Win64-Shipping*"
        })

        if ($targets.Count -gt 0) {
            $targetWasSeen = $true
            $noTargetSince = $null
            foreach ($process in $targets) {
                try {
                    if ($process.PriorityClass -in @("Idle", "BelowNormal", "Normal")) {
                        $process.PriorityClass = "AboveNormal"
                    }
                } catch {}
            }
        } elseif ($targetWasSeen) {
            if (-not $noTargetSince) { $noTargetSince = Get-Date }
            if (((Get-Date) - $noTargetSince).TotalSeconds -ge 90) { break }
        } elseif ((Get-Date) -ge $initialDeadline) {
            break
        }

        Start-Sleep -Seconds 4
    }
} finally {
    Restore-NormalPlan
}

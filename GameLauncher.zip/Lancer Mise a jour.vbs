Option Explicit

Dim shell, fso, appDir, updaterPath, command
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appDir = fso.GetParentFolderName(WScript.ScriptFullName)
updaterPath = appDir & "\Updater.ps1"
command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & updaterPath & """ -InstallDir """ & appDir & """"
shell.Run command, 0, False

@echo off
setlocal
title Installation de NIGHTCORE LAUNCHER
cd /d "%~dp0"

set "INSTALL_DIR=%LOCALAPPDATA%\LucasGameLauncher"
set "LOG_FILE=%TEMP%\GameLauncher-installation.log"

echo Installation de NIGHTCORE LAUNCHER... > "%LOG_FILE%"
echo Source: %CD%>> "%LOG_FILE%"
echo Destination: %INSTALL_DIR%>> "%LOG_FILE%"

if not exist "GameLauncher.ps1" goto :missing
if not exist "RetracFpsMonitor.ps1" goto :missing
if not exist "Updater.ps1" goto :missing
if not exist "Lancer Game Launcher.vbs" goto :missing
if not exist "Lancer Mise a jour.vbs" goto :missing
if not exist "game-launcher.ico" goto :missing
if not exist "launcher-banner.png" goto :missing

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%" >> "%LOG_FILE%" 2>&1
if errorlevel 1 goto :failed

copy /y "GameLauncher.ps1" "%INSTALL_DIR%\GameLauncher.ps1" >> "%LOG_FILE%" 2>&1
copy /y "RetracFpsMonitor.ps1" "%INSTALL_DIR%\RetracFpsMonitor.ps1" >> "%LOG_FILE%" 2>&1
copy /y "Updater.ps1" "%INSTALL_DIR%\Updater.ps1" >> "%LOG_FILE%" 2>&1
copy /y "Lancer Game Launcher.vbs" "%INSTALL_DIR%\Lancer Game Launcher.vbs" >> "%LOG_FILE%" 2>&1
copy /y "Lancer Mise a jour.vbs" "%INSTALL_DIR%\Lancer Mise a jour.vbs" >> "%LOG_FILE%" 2>&1
copy /y "game-launcher.ico" "%INSTALL_DIR%\game-launcher.ico" >> "%LOG_FILE%" 2>&1
copy /y "launcher-banner.png" "%INSTALL_DIR%\launcher-banner.png" >> "%LOG_FILE%" 2>&1
if not exist "%INSTALL_DIR%\games.json" copy /y "games.json" "%INSTALL_DIR%\games.json" >> "%LOG_FILE%" 2>&1
if errorlevel 1 goto :failed

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $d=$env:LOCALAPPDATA+'\LucasGameLauncher'; Get-ChildItem -LiteralPath $d -File | Unblock-File -ErrorAction SilentlyContinue; $desktop=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'NIGHTCORE LAUNCHER.lnk')); $s.TargetPath=(Join-Path $env:SystemRoot 'System32\wscript.exe'); $s.Arguments='"""'+(Join-Path $d 'Lancer Game Launcher.vbs')+'"""'; $s.WorkingDirectory=$d; $s.IconLocation=(Join-Path $d 'game-launcher.ico')+',0'; $s.Description='Lancer vos jeux et logiciels'; $s.Save(); if(-not (Test-Path (Join-Path $desktop 'NIGHTCORE LAUNCHER.lnk'))){throw 'Le raccourci na pas ete cree'}" >> "%LOG_FILE%" 2>&1
if errorlevel 1 goto :failed

echo Installation terminee.>> "%LOG_FILE%"
echo.
echo ============================================
echo   NIGHTCORE LAUNCHER EST INSTALLE
echo ============================================
echo.
echo Le raccourci "NIGHTCORE LAUNCHER" est sur le Bureau.
echo.
choice /c ON /n /m "Voulez-vous le lancer maintenant ? [O/N] "
if errorlevel 2 goto :end
start "" wscript.exe "%INSTALL_DIR%\Lancer Game Launcher.vbs"
goto :end

:missing
echo ERREUR: fichiers manquants.>> "%LOG_FILE%"
echo.
echo ERREUR : les fichiers du launcher sont introuvables.
echo.
echo Faites un clic droit sur GameLauncher.zip,
echo choisissez "Extraire tout", puis ouvrez le dossier extrait
echo et relancez "INSTALLER LE LAUNCHER.cmd".
echo.
pause
exit /b 1

:failed
echo.
echo L'installation a echoue.
echo Envoyez ce fichier pour trouver la panne :
echo %LOG_FILE%
echo.
pause
exit /b 1

:end
endlocal

@echo off
setlocal
title Installation de Game Launcher
cd /d "%~dp0"

set "INSTALL_DIR=%LOCALAPPDATA%\LucasGameLauncher"
set "LOG_FILE=%TEMP%\GameLauncher-installation.log"

echo Installation de Game Launcher... > "%LOG_FILE%"
echo Source: %CD%>> "%LOG_FILE%"
echo Destination: %INSTALL_DIR%>> "%LOG_FILE%"

if not exist "GameLauncher.ps1" goto :missing
if not exist "RetracFpsMonitor.ps1" goto :missing
if not exist "game-launcher.ico" goto :missing
if not exist "launcher-banner.png" goto :missing

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%" >> "%LOG_FILE%" 2>&1
if errorlevel 1 goto :failed

copy /y "GameLauncher.ps1" "%INSTALL_DIR%\GameLauncher.ps1" >> "%LOG_FILE%" 2>&1
copy /y "RetracFpsMonitor.ps1" "%INSTALL_DIR%\RetracFpsMonitor.ps1" >> "%LOG_FILE%" 2>&1
copy /y "game-launcher.ico" "%INSTALL_DIR%\game-launcher.ico" >> "%LOG_FILE%" 2>&1
copy /y "launcher-banner.png" "%INSTALL_DIR%\launcher-banner.png" >> "%LOG_FILE%" 2>&1
if not exist "%INSTALL_DIR%\games.json" copy /y "games.json" "%INSTALL_DIR%\games.json" >> "%LOG_FILE%" 2>&1
if errorlevel 1 goto :failed

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $d=$env:LOCALAPPDATA+'\LucasGameLauncher'; Get-ChildItem -LiteralPath $d -File | Unblock-File -ErrorAction SilentlyContinue; $desktop=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'Game Launcher.lnk')); $s.TargetPath=(Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'); $s.Arguments='-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """'+(Join-Path $d 'GameLauncher.ps1')+'"""'; $s.WorkingDirectory=$d; $s.IconLocation=(Join-Path $d 'game-launcher.ico')+',0'; $s.Description='Lancer vos jeux'; $s.Save(); if(-not (Test-Path (Join-Path $desktop 'Game Launcher.lnk'))){throw 'Le raccourci na pas ete cree'}" >> "%LOG_FILE%" 2>&1
if errorlevel 1 goto :failed

echo Installation terminee.>> "%LOG_FILE%"
echo.
echo ============================================
echo   GAME LAUNCHER EST INSTALLE
echo ============================================
echo.
echo Le raccourci "Game Launcher" est sur le Bureau.
echo.
choice /c ON /n /m "Voulez-vous le lancer maintenant ? [O/N] "
if errorlevel 2 goto :end
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%INSTALL_DIR%\GameLauncher.ps1"
goto :end

:missing
echo ERREUR: fichiers manquants.>> "%LOG_FILE%"
echo.
echo ERREUR : les fichiers du launcher sont introuvables.
echo.
echo Faites un clic droit sur GameLauncher.zip,
echo choisissez "Extraire tout", puis ouvrez le dossier extrait
echo et relancez "INSTALLER LE LAUNCHER.cmd".
echo.
pause
exit /b 1

:failed
echo.
echo L'installation a echoue.
echo Envoyez ce fichier pour trouver la panne :
echo %LOG_FILE%
echo.
pause
exit /b 1

:end
endlocal

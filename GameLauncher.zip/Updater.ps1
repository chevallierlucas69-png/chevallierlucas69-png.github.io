param(
    [Parameter(Mandatory = $true)]
    [string]$InstallDir
)

Add-Type -AssemblyName PresentationFramework
$ErrorActionPreference = "Stop"
$siteRoot = "https://chevallierlucas69-png.github.io"
$tempDir = Join-Path ([System.IO.Path]::GetTempPath()) ("LucasGameLauncher-Update-" + [guid]::NewGuid().ToString("N"))

try {
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $manifestPath = Join-Path $tempDir "version.json"
    $zipPath = Join-Path $tempDir "GameLauncher.zip"
    $extractDir = Join-Path $tempDir "Package"

    Invoke-WebRequest -UseBasicParsing -Uri "$siteRoot/version.json?cache=$([DateTime]::UtcNow.Ticks)" -OutFile $manifestPath
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    Invoke-WebRequest -UseBasicParsing -Uri "$siteRoot/GameLauncher.zip?cache=$([DateTime]::UtcNow.Ticks)" -OutFile $zipPath

    $downloadHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
    if ($downloadHash -ne [string]$manifest.sha256) {
        throw "La verification de securite du fichier a echoue."
    }

    Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force
    $requiredFiles = @(
        "GameLauncher.ps1", "RetracFpsMonitor.ps1", "Updater.ps1",
        "Lancer Game Launcher.vbs", "Lancer Mise a jour.vbs",
        "game-launcher.ico", "launcher-banner.png"
    )
    foreach ($file in $requiredFiles) {
        $source = Join-Path $extractDir $file
        if (-not (Test-Path -LiteralPath $source)) {
            throw "Le fichier $file manque dans la mise a jour."
        }
    }

    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    foreach ($file in $requiredFiles) {
        Copy-Item -LiteralPath (Join-Path $extractDir $file) -Destination (Join-Path $InstallDir $file) -Force
        Unblock-File -LiteralPath (Join-Path $InstallDir $file) -ErrorAction SilentlyContinue
    }
    Set-Content -LiteralPath (Join-Path $InstallDir "version.txt") -Value ([string]$manifest.version) -Encoding ASCII

    [System.Windows.MessageBox]::Show(
        "Game Launcher a ete mis a jour vers la version $($manifest.version).",
        "Mise a jour terminee",
        "OK",
        "Information"
    ) | Out-Null

    Start-Process wscript.exe -ArgumentList "`"$(Join-Path $InstallDir 'Lancer Game Launcher.vbs')`""
} catch {
    [System.Windows.MessageBox]::Show(
        "La mise a jour a echoue.`n`n$($_.Exception.Message)",
        "Game Launcher",
        "OK",
        "Error"
    ) | Out-Null
} finally {
    if (Test-Path -LiteralPath $tempDir) {
        Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

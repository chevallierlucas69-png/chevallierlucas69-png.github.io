Option Explicit

Dim shell, fso, sourceDir, installDir, desktopDir, shortcutPath, shortcut
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

sourceDir = fso.GetParentFolderName(WScript.ScriptFullName)
installDir = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\LucasGameLauncher"

If Not fso.FolderExists(installDir) Then
  fso.CreateFolder(installDir)
End If

fso.CopyFile sourceDir & "\GameLauncher.ps1", installDir & "\", True
fso.CopyFile sourceDir & "\RetracFpsMonitor.ps1", installDir & "\", True
fso.CopyFile sourceDir & "\Lancer Game Launcher.vbs", installDir & "\", True
fso.CopyFile sourceDir & "\game-launcher.ico", installDir & "\", True
fso.CopyFile sourceDir & "\launcher-banner.png", installDir & "\", True

If Not fso.FileExists(installDir & "\games.json") Then
  fso.CopyFile sourceDir & "\games.json", installDir & "\", False
End If

desktopDir = shell.SpecialFolders("Desktop")
shortcutPath = desktopDir & "\NIGHTCORE LAUNCHER.lnk"
Set shortcut = shell.CreateShortcut(shortcutPath)
shortcut.TargetPath = shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\wscript.exe"
shortcut.Arguments = """" & installDir & "\Lancer Game Launcher.vbs"""
shortcut.WorkingDirectory = installDir
shortcut.IconLocation = installDir & "\game-launcher.ico,0"
shortcut.Description = "Lancer vos jeux"
shortcut.Save

MsgBox "NIGHTCORE LAUNCHER est installe sur votre Bureau.", 64, "Installation terminee"

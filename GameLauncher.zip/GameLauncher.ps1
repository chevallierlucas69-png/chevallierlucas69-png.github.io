Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class GameLauncherIdentity {
    [DllImport("shell32.dll", SetLastError = true)]
    public static extern int SetCurrentProcessExplicitAppUserModelID(
        [MarshalAs(UnmanagedType.LPWStr)] string appID
    );
}
"@
[GameLauncherIdentity]::SetCurrentProcessExplicitAppUserModelID("Lucas.GameLauncher") | Out-Null

$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$gamesFile = Join-Path $appDir "games.json"
$normalPowerPlanFile = Join-Path $appDir "normal-power-plan.txt"
$highPerformanceGuid = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
$launcherVersion = "1.5.0"
$settingsFile = Join-Path $appDir "settings.json"
$backupDir = Join-Path ([Environment]::GetFolderPath("MyDocuments")) "LucasGameLauncherBackup"
$backupGamesFile = Join-Path $backupDir "games.json"
$script:activePlaySessions = @{}
$script:pendingPlaySessions = @{}

function Get-LauncherSettings {
    $defaults = [PSCustomObject]@{
        Theme = "Violet"
        CustomBackground = ""
        AutoUpdate = $false
        AutoBackup = $true
    }
    if (-not (Test-Path -LiteralPath $settingsFile)) { return $defaults }
    try {
        $saved = Get-Content -LiteralPath $settingsFile -Raw | ConvertFrom-Json
        foreach ($property in $defaults.PSObject.Properties) {
            if ($null -eq $saved.($property.Name)) {
                $saved | Add-Member -NotePropertyName $property.Name -NotePropertyValue $property.Value -Force
            }
        }
        return $saved
    } catch { return $defaults }
}

function Save-LauncherSettings($settings) {
    $settings | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $settingsFile -Encoding UTF8
}

$launcherSettings = Get-LauncherSettings

function Get-Games {
    $needsRestore = -not (Test-Path -LiteralPath $gamesFile)
    if (-not $needsRestore -and (Test-Path -LiteralPath $gamesFile)) {
        $currentLibraryText = (Get-Content -LiteralPath $gamesFile -Raw).Trim()
        $needsRestore = $currentLibraryText -in @("", "[]", "null")
    }
    if ($needsRestore -and (Test-Path -LiteralPath $backupGamesFile)) {
        Copy-Item -LiteralPath $backupGamesFile -Destination $gamesFile -Force
    }
    if (-not (Test-Path -LiteralPath $gamesFile)) { return @() }
    try {
        $items = Get-Content -LiteralPath $gamesFile -Raw | ConvertFrom-Json
        return @($items)
    } catch {
        [System.Windows.MessageBox]::Show(
            "La liste des jeux est illisible. Elle va etre recreee.",
            "Game Launcher"
        ) | Out-Null
        return @()
    }
}

function Save-Games([array]$games) {
    $games | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $gamesFile -Encoding UTF8
    if ($launcherSettings.AutoBackup) {
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        Copy-Item -LiteralPath $gamesFile -Destination $backupGamesFile -Force
    }
}

function Add-DetectedSoftware {
    $wantedApps = @(
        "CapCut", "Discord", "OBS Studio", "Google Chrome", "Microsoft Edge",
        "Spotify", "Steam", "Epic Games Launcher", "Battle.net", "VLC",
        "WhatsApp", "Microsoft Teams", "Telegram", "Mozilla Firefox",
        "NVIDIA App", "Logitech G HUB", "Medal", "BlueStacks 5", "PS App",
        "PlayStation", "Stream Controller", "Wallpaper Engine",
        "Streamlabs Desktop", "Movavi Video Editor", "Outplayed"
    )
    $shortcutFolders = @(
        (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"),
        (Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs"),
        [Environment]::GetFolderPath("Desktop"),
        (Join-Path $env:PUBLIC "Desktop"),
        (Join-Path $env:USERPROFILE "OneDrive\Desktop"),
        (Join-Path $env:USERPROFILE "OneDrive\Bureau")
    )
    $found = @()
    foreach ($folder in $shortcutFolders) {
        if (-not (Test-Path -LiteralPath $folder)) { continue }
        foreach ($shortcut in Get-ChildItem -LiteralPath $folder -Filter "*.lnk" -File -Recurse -ErrorAction SilentlyContinue) {
            foreach ($appName in $wantedApps) {
                if ($shortcut.BaseName -like "*$appName*") {
                    $found += [PSCustomObject]@{
                        Name = $appName
                        Path = $shortcut.FullName
                        Category = "Software"
                    }
                    break
                }
            }
        }
    }

    $knownPaths = [ordered]@{
        "CapCut" = @(
            (Join-Path $env:LOCALAPPDATA "CapCut\Apps\CapCut.exe"),
            (Join-Path $env:LOCALAPPDATA "CapCut\CapCut.exe")
        )
        "Discord" = @((Join-Path $env:LOCALAPPDATA "Discord\Update.exe"))
        "Spotify" = @((Join-Path $env:APPDATA "Spotify\Spotify.exe"))
        "OBS Studio" = @((Join-Path ${env:ProgramFiles} "obs-studio\bin\64bit\obs64.exe"))
        "Google Chrome" = @(
            (Join-Path ${env:ProgramFiles} "Google\Chrome\Application\chrome.exe"),
            (Join-Path ${env:ProgramFiles(x86)} "Google\Chrome\Application\chrome.exe")
        )
    }
    foreach ($entry in $knownPaths.GetEnumerator()) {
        foreach ($candidate in $entry.Value) {
            if ($candidate -and (Test-Path -LiteralPath $candidate)) {
                $found += [PSCustomObject]@{
                    Name = [string]$entry.Key
                    Path = $candidate
                    Category = "Software"
                }
                break
            }
        }
    }

    $items = @(Get-Games)
    $added = 0
    $uniqueSoftware = @($found | Group-Object Name | ForEach-Object { $_.Group | Select-Object -First 1 })
    foreach ($software in $uniqueSoftware) {
        if ($items.Path -contains $software.Path) { continue }
        if (@($items | Where-Object {
            [string]$_.Category -eq "Software" -and [string]$_.Name -eq $software.Name
        }).Count -gt 0) { continue }
        $items += $software
        $added++
    }
    Save-Games $items
    return $added
}

function Add-DetectedGames {
    $found = @()
    $desktopFolders = @(
        [Environment]::GetFolderPath("Desktop"),
        (Join-Path $env:PUBLIC "Desktop"),
        (Join-Path $env:USERPROFILE "OneDrive\Desktop"),
        (Join-Path $env:USERPROFILE "OneDrive\Bureau")
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique

    $excludedNames = @(
        "Discord", "CapCut", "Chrome", "Edge", "Firefox", "Spotify", "Steam",
        "Epic Games", "Battle.net", "OBS", "WhatsApp", "Teams", "Telegram",
        "Corbeille", "Ce PC", "Game Launcher", "NVIDIA App", "Logitech G HUB",
        "Medal", "BlueStacks", "PS App", "PlayStation", "Stream Controller",
        "Wallpaper Engine", "Streamlabs", "Movavi", "Outplayed"
    )
    foreach ($folder in $desktopFolders) {
        foreach ($shortcut in Get-ChildItem -LiteralPath $folder -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -in @(".lnk", ".url") }) {
            $isExcluded = $false
            foreach ($excluded in $excludedNames) {
                if ($shortcut.BaseName -like "*$excluded*") { $isExcluded = $true; break }
            }
            if (-not $isExcluded) {
                $found += [PSCustomObject]@{
                    Name = $shortcut.BaseName
                    Path = $shortcut.FullName
                    Category = "Game"
                }
            }
        }
    }

    $steamAppsFolders = @()
    $defaultSteamApps = Join-Path ${env:ProgramFiles(x86)} "Steam\steamapps"
    if (Test-Path -LiteralPath $defaultSteamApps) { $steamAppsFolders += $defaultSteamApps }
    $libraryFile = Join-Path $defaultSteamApps "libraryfolders.vdf"
    if (Test-Path -LiteralPath $libraryFile) {
        $libraryText = Get-Content -LiteralPath $libraryFile -Raw
        foreach ($match in [regex]::Matches($libraryText, '"path"\s+"([^"]+)"')) {
            $libraryRoot = $match.Groups[1].Value -replace '\\\\', '\'
            $steamApps = Join-Path $libraryRoot "steamapps"
            if (Test-Path -LiteralPath $steamApps) { $steamAppsFolders += $steamApps }
        }
    }

    $generatedFolder = Join-Path $appDir "JeuxDetectes"
    New-Item -ItemType Directory -Path $generatedFolder -Force | Out-Null
    foreach ($steamApps in $steamAppsFolders | Select-Object -Unique) {
        foreach ($manifest in Get-ChildItem -LiteralPath $steamApps -Filter "appmanifest_*.acf" -File -ErrorAction SilentlyContinue) {
            $manifestText = Get-Content -LiteralPath $manifest.FullName -Raw
            $appIdMatch = [regex]::Match($manifestText, '"appid"\s+"([^"]+)"')
            $nameMatch = [regex]::Match($manifestText, '"name"\s+"([^"]+)"')
            if (-not $appIdMatch.Success -or -not $nameMatch.Success) { continue }
            $gameName = $nameMatch.Groups[1].Value
            $safeName = ($gameName -replace '[\\/:*?"<>|]', '_')
            $urlPath = Join-Path $generatedFolder "$safeName.url"
            @(
                "[InternetShortcut]",
                "URL=steam://rungameid/$($appIdMatch.Groups[1].Value)",
                "IconFile=${env:ProgramFiles(x86)}\Steam\steam.exe",
                "IconIndex=0"
            ) | Set-Content -LiteralPath $urlPath -Encoding ASCII
            $found += [PSCustomObject]@{ Name = $gameName; Path = $urlPath; Category = "Game" }
        }
    }

    $epicManifests = Join-Path $env:ProgramData "Epic\EpicGamesLauncher\Data\Manifests"
    if (Test-Path -LiteralPath $epicManifests) {
        foreach ($manifest in Get-ChildItem -LiteralPath $epicManifests -Filter "*.item" -File -ErrorAction SilentlyContinue) {
            try {
                $epic = Get-Content -LiteralPath $manifest.FullName -Raw | ConvertFrom-Json
                $epicExe = Join-Path ([string]$epic.InstallLocation) ([string]$epic.LaunchExecutable)
                if ($epic.DisplayName -and (Test-Path -LiteralPath $epicExe)) {
                    $found += [PSCustomObject]@{
                        Name = [string]$epic.DisplayName
                        Path = $epicExe
                        Category = "Game"
                    }
                }
            } catch {}
        }
    }

    $items = @(Get-Games)
    $added = 0
    foreach ($game in @($found | Group-Object Name | ForEach-Object { $_.Group | Select-Object -First 1 })) {
        if ($items.Path -contains $game.Path) { continue }
        if (@($items | Where-Object {
            [string]$_.Category -ne "Software" -and [string]$_.Name -eq $game.Name
        }).Count -gt 0) { continue }
        $items += $game
        $added++
    }
    Save-Games $items
    return $added
}

function Register-GameLaunch([string]$target) {
    $games = @(Get-Games)
    foreach ($game in $games) {
        if ([string]$game.Path -eq $target) {
            $game | Add-Member -NotePropertyName "LastPlayed" -NotePropertyValue ((Get-Date).ToString("o")) -Force
            $newLaunchCount = 1
            if ($game.LaunchCount) { $newLaunchCount = [int]$game.LaunchCount + 1 }
            $game | Add-Member -NotePropertyName "LaunchCount" -NotePropertyValue $newLaunchCount -Force
        }
    }
    Save-Games $games
}

function Add-PlayTime([string]$target, [double]$seconds) {
    if ($seconds -lt 1) { return }
    $items = @(Get-Games)
    foreach ($item in $items) {
        if ([string]$item.Path -eq $target) {
            $total = 0
            if ($item.PlayTimeSeconds) { $total = [double]$item.PlayTimeSeconds }
            $item | Add-Member -NotePropertyName "PlayTimeSeconds" -NotePropertyValue ([math]::Round($total + $seconds)) -Force
        }
    }
    Save-Games $items
}

function Format-PlayTime([double]$seconds) {
    if ($seconds -lt 60) { return "moins d'une minute" }
    $span = [TimeSpan]::FromSeconds($seconds)
    if ($span.TotalHours -ge 1) { return "$([math]::Floor($span.TotalHours)) h $($span.Minutes) min" }
    return "$($span.Minutes) min"
}

function Update-PlaySessions {
    foreach ($target in @($script:pendingPlaySessions.Keys)) {
        $processName = [string]$script:pendingPlaySessions[$target]
        $process = Get-Process -Name $processName -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($process) {
            $script:activePlaySessions[$target] = [PSCustomObject]@{
                ProcessId = $process.Id
                Started = Get-Date
            }
            $script:pendingPlaySessions.Remove($target)
        }
    }
    foreach ($target in @($script:activePlaySessions.Keys)) {
        $session = $script:activePlaySessions[$target]
        if (-not (Get-Process -Id $session.ProcessId -ErrorAction SilentlyContinue)) {
            Add-PlayTime $target ((Get-Date) - $session.Started).TotalSeconds
            $script:activePlaySessions.Remove($target)
            Refresh-Games
        }
    }
}

function Toggle-GameFavorite([string]$target) {
    $games = @(Get-Games)
    foreach ($game in $games) {
        if ([string]$game.Path -eq $target) {
            $newValue = -not [bool]$game.Favorite
            $game | Add-Member -NotePropertyName "Favorite" -NotePropertyValue $newValue -Force
        }
    }
    Save-Games $games
}

function Update-LibraryPath([string]$oldPath, [string]$newPath) {
    $items = @(Get-Games)
    foreach ($item in $items) {
        if ([string]$item.Path -eq $oldPath) {
            $item.Path = $newPath
        }
    }
    Save-Games $items
}

function Find-MovedLibraryItem([string]$missingPath) {
    $fileName = [System.IO.Path]::GetFileName($missingPath)
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($missingPath)
    $searchFolders = @(
        [Environment]::GetFolderPath("Desktop"),
        (Join-Path $env:PUBLIC "Desktop"),
        (Join-Path $env:USERPROFILE "OneDrive\Desktop"),
        (Join-Path $env:USERPROFILE "OneDrive\Bureau"),
        (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"),
        (Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs")
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique

    foreach ($folder in $searchFolders) {
        $exact = Get-ChildItem -LiteralPath $folder -File -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -ieq $fileName } |
            Select-Object -First 1
        if ($exact) { return $exact.FullName }
    }
    foreach ($folder in $searchFolders) {
        $similar = Get-ChildItem -LiteralPath $folder -File -Recurse -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Extension -in @(".exe", ".lnk", ".url") -and
                $_.BaseName -like "*$baseName*"
            } |
            Select-Object -First 1
        if ($similar) { return $similar.FullName }
    }
    return $null
}

function Get-ActivePowerPlan {
    $result = powercfg /getactivescheme 2>$null
    $match = [regex]::Match(($result -join " "), "[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")
    if ($match.Success) { return $match.Value.ToLowerInvariant() }
    return ""
}

function Set-FpsMode([bool]$enabled) {
    try {
        if ($enabled) {
            $currentPlan = Get-ActivePowerPlan
            if ($currentPlan -and $currentPlan -ne $highPerformanceGuid) {
                Set-Content -LiteralPath $normalPowerPlanFile -Value $currentPlan -Encoding ASCII
            }
            powercfg /setactive SCHEME_MIN | Out-Null
            New-Item -Path "HKCU:\Software\Microsoft\GameBar" -Force | Out-Null
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Type DWord -Value 1
        } else {
            $normalPlan = "381b4222-f694-41f0-9685-ff5bb260df2e"
            if (Test-Path -LiteralPath $normalPowerPlanFile) {
                $savedPlan = (Get-Content -LiteralPath $normalPowerPlanFile -Raw).Trim()
                if ($savedPlan -match "^[0-9a-fA-F-]{36}$") { $normalPlan = $savedPlan }
            }
            powercfg /setactive $normalPlan | Out-Null
        }
    } catch {
        [System.Windows.MessageBox]::Show(
            "Le mode FPS ne peut pas etre modifie.`n`n$($_.Exception.Message)",
            "Game Launcher",
            "OK",
            "Error"
        ) | Out-Null
    }
}

function Optimize-RetracProcesses {
    if ((Get-ActivePowerPlan) -ne $highPerformanceGuid) { return }

    $targets = Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -ieq "retrac" -or
        $_.ProcessName -like "FortniteClient-Win64-Shipping*"
    }
    foreach ($process in $targets) {
        try {
            if ($process.PriorityClass -in @("Idle", "BelowNormal", "Normal")) {
                $process.PriorityClass = "AboveNormal"
            }
        } catch {}
    }
}

function Start-RetracFpsMonitor {
    $monitorPath = Join-Path $appDir "RetracFpsMonitor.ps1"
    if (-not (Test-Path -LiteralPath $monitorPath)) { return }

    $alreadyRunning = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -eq "powershell.exe" -and $_.CommandLine -like "*RetracFpsMonitor.ps1*" } |
        Select-Object -First 1
    if ($alreadyRunning) { return }

    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = "powershell.exe"
    $startInfo.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$monitorPath`" -NormalPlanFile `"$normalPowerPlanFile`""
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
    [System.Diagnostics.Process]::Start($startInfo) | Out-Null
}

function Start-Game([string]$target) {
    if (-not (Test-Path -LiteralPath $target)) {
        $repairedPath = Find-MovedLibraryItem $target
        if ($repairedPath) {
            Update-LibraryPath $target $repairedPath
            Start-Game $repairedPath
            return
        }

        $answer = [System.Windows.MessageBox]::Show(
            "Le raccourci a ete deplace ou supprime.`n`nVoulez-vous retrouver le jeu sur ce PC ?",
            "Reparer le raccourci",
            "YesNo",
            "Question"
        )
        if ($answer -eq "Yes") {
            $repairDialog = New-Object System.Windows.Forms.OpenFileDialog
            $repairDialog.Title = "Selectionnez le jeu ou son nouveau raccourci"
            $repairDialog.Filter = "Jeux et raccourcis (*.exe;*.lnk;*.url)|*.exe;*.lnk;*.url|Tous les fichiers (*.*)|*.*"
            if ($repairDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                Update-LibraryPath $target $repairDialog.FileName
                Start-Game $repairDialog.FileName
            }
        }
        return
    }

    try {
        $libraryItem = Get-Games | Where-Object { [string]$_.Path -eq $target } | Select-Object -First 1
        $isSoftware = [string]$libraryItem.Category -eq "Software"
        $itemFpsEnabled = $true
        if ($null -ne $libraryItem.FpsEnabled) { $itemFpsEnabled = [bool]$libraryItem.FpsEnabled }
        if (-not $isSoftware -and $itemFpsEnabled -and $autoFpsCheck -and $autoFpsCheck.IsChecked) {
            Set-FpsMode $true
            Update-FpsButton
            if ([System.IO.Path]::GetFileName($target) -ieq "retrac.exe") {
                Start-RetracFpsMonitor
            }
        }

        if ([System.IO.Path]::GetExtension($target) -ieq ".url") {
            $urlLine = Get-Content -LiteralPath $target |
                Where-Object { $_ -like "URL=*" } |
                Select-Object -First 1
            if (-not $urlLine) { throw "Adresse Steam absente du raccourci." }
            $launchTarget = $urlLine.Substring(4)
            $steamMatch = [regex]::Match($launchTarget, "^steam://rungameid/([0-9]+)$")
            $steamExe = "${env:ProgramFiles(x86)}\Steam\steam.exe"
            if ($steamMatch.Success -and (Test-Path -LiteralPath $steamExe)) {
                $steamAppId = $steamMatch.Groups[1].Value
                $steamGameExe = Find-SteamGameExecutable $steamAppId
                if ($steamGameExe) {
                    $script:pendingPlaySessions[$target] = [System.IO.Path]::GetFileNameWithoutExtension($steamGameExe)
                }
                if ($steamAppId -eq "1172470") {
                    Start-Process -FilePath $steamExe -ArgumentList "-applaunch", $steamAppId, "+cl_showfps", "1"
                } else {
                    Start-Process -FilePath $steamExe -ArgumentList "-applaunch", $steamAppId
                }
            } else {
                Start-Process -FilePath $launchTarget
            }
        } else {
            $gameProcess = Start-Process -FilePath $target -PassThru
            if (-not $isSoftware -and $gameProcess) {
                $script:activePlaySessions[$target] = [PSCustomObject]@{
                    ProcessId = $gameProcess.Id
                    Started = Get-Date
                }
            }
            Start-Sleep -Milliseconds 500
            try {
                if (-not $isSoftware -and $gameProcess -and -not $gameProcess.HasExited) {
                    $gameProcess.PriorityClass = "High"
                }
            } catch {}
        }
    } catch {
        [System.Windows.MessageBox]::Show(
            "Le jeu ne peut pas etre lance.`n`n$($_.Exception.Message)",
            "Game Launcher",
            "OK",
            "Error"
        ) | Out-Null
    }
}

function Find-SteamGameExecutable([string]$appId) {
    $steamAppsFolders = @()
    $defaultSteamApps = Join-Path ${env:ProgramFiles(x86)} "Steam\steamapps"
    if (Test-Path -LiteralPath $defaultSteamApps) { $steamAppsFolders += $defaultSteamApps }
    $libraryFile = Join-Path $defaultSteamApps "libraryfolders.vdf"
    if (Test-Path -LiteralPath $libraryFile) {
        $libraryText = Get-Content -LiteralPath $libraryFile -Raw
        foreach ($match in [regex]::Matches($libraryText, '"path"\s+"([^"]+)"')) {
            $libraryRoot = $match.Groups[1].Value -replace '\\\\', '\'
            $steamApps = Join-Path $libraryRoot "steamapps"
            if (Test-Path -LiteralPath $steamApps) { $steamAppsFolders += $steamApps }
        }
    }

    foreach ($steamApps in $steamAppsFolders | Select-Object -Unique) {
        $manifestPath = Join-Path $steamApps "appmanifest_$appId.acf"
        if (-not (Test-Path -LiteralPath $manifestPath)) { continue }
        $manifestText = Get-Content -LiteralPath $manifestPath -Raw
        $installMatch = [regex]::Match($manifestText, '"installdir"\s+"([^"]+)"')
        if (-not $installMatch.Success) { continue }
        $gameFolder = Join-Path (Join-Path $steamApps "common") $installMatch.Groups[1].Value
        if (-not (Test-Path -LiteralPath $gameFolder)) { continue }
        $gameExe = Get-ChildItem -LiteralPath $gameFolder -Filter "*.exe" -File -Recurse -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -notmatch "unins|uninstall|crash|report|easyanticheat|unitycrashhandler|redist|setup"
            } |
            Sort-Object Length -Descending |
            Select-Object -First 1
        if ($gameExe) { return $gameExe.FullName }
    }
    return $null
}

function Get-GameIcon([string]$target) {
    $iconSource = $null
    if ([System.IO.Path]::GetExtension($target) -ieq ".url") {
        $urlLine = Get-Content -LiteralPath $target |
            Where-Object { $_ -like "URL=*" } |
            Select-Object -First 1
        if ($urlLine) {
            $steamIconMatch = [regex]::Match($urlLine.Substring(4), "^steam://rungameid/([0-9]+)$")
            if ($steamIconMatch.Success) {
                $steamGameExe = Find-SteamGameExecutable $steamIconMatch.Groups[1].Value
                if ($steamGameExe) { $iconSource = $steamGameExe }
            }
        }
        $iconLine = Get-Content -LiteralPath $target |
            Where-Object { $_ -like "IconFile=*" } |
            Select-Object -First 1
        if (-not $iconSource -and $iconLine) {
            $iconPath = $iconLine.Substring(9)
            if (Test-Path -LiteralPath $iconPath) { $iconSource = $iconPath }
        }
    }

    if ([System.IO.Path]::GetExtension($target) -ieq ".lnk") {
        try {
            $shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($target)
            $shortcutIcon = ([string]$shortcut.IconLocation -split ",")[0]
            if ($shortcutIcon -and (Test-Path -LiteralPath $shortcutIcon)) {
                $iconSource = $shortcutIcon
            } elseif ($shortcut.TargetPath -and (Test-Path -LiteralPath $shortcut.TargetPath)) {
                $iconSource = $shortcut.TargetPath
            }
        } catch {}
    }
    if ([System.IO.Path]::GetExtension($target) -ieq ".exe") {
        $iconSource = $target
    }
    if (-not $iconSource) { return $null }

    $sourceExtension = [System.IO.Path]::GetExtension($iconSource).ToLowerInvariant()
    if ($sourceExtension -in @(".png", ".jpg", ".jpeg", ".bmp", ".gif", ".ico")) {
        return $iconSource
    }

    try {
        $iconCache = Join-Path $appDir "IconCache"
        New-Item -ItemType Directory -Path $iconCache -Force | Out-Null
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try {
            $hashBytes = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($iconSource.ToLowerInvariant()))
        } finally {
            $sha.Dispose()
        }
        $hashName = ([System.BitConverter]::ToString($hashBytes) -replace "-", "").Substring(0,16)
        $cachedIcon = Join-Path $iconCache "$hashName.png"
        if (-not (Test-Path -LiteralPath $cachedIcon)) {
            $icon = [System.Drawing.Icon]::ExtractAssociatedIcon($iconSource)
            if (-not $icon) { return $null }
            try {
                $bitmap = $icon.ToBitmap()
                try {
                    $bitmap.Save($cachedIcon, [System.Drawing.Imaging.ImageFormat]::Png)
                } finally {
                    $bitmap.Dispose()
                }
            } finally {
                $icon.Dispose()
            }
        }
        return $cachedIcon
    } catch {}
    return $null
}

$window = New-Object System.Windows.Window
$window.Title = "Game Launcher"
$window.Width = 1040
$window.Height = 680
$window.MinWidth = 720
$window.MinHeight = 480
$window.WindowStartupLocation = "CenterScreen"
$window.Background = "#10131A"
$windowIconPath = Join-Path $appDir "game-launcher.ico"
if (Test-Path -LiteralPath $windowIconPath) {
    try {
        $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create(
            (New-Object System.Uri -ArgumentList $windowIconPath)
        )
    } catch {}
}

$root = New-Object System.Windows.Controls.DockPanel
$root.Margin = 22
$window.Content = $root

$headerBorder = New-Object System.Windows.Controls.Border
$headerBorder.Height = 190
$headerBorder.Padding = 24
$headerBorder.Margin = "0,0,0,18"
$headerBorder.CornerRadius = 14
$headerBorder.BorderBrush = "#493B86"
$headerBorder.BorderThickness = 1
[System.Windows.Controls.DockPanel]::SetDock($headerBorder, "Top")

$bannerPath = Join-Path $appDir "launcher-banner.png"
if (Test-Path -LiteralPath $bannerPath) {
    $bannerBitmap = New-Object System.Windows.Media.Imaging.BitmapImage
    $bannerBitmap.BeginInit()
    $bannerBitmap.CacheOption = "OnLoad"
    $bannerBitmap.UriSource = New-Object System.Uri -ArgumentList $bannerPath
    $bannerBitmap.EndInit()
    $bannerBrush = New-Object System.Windows.Media.ImageBrush
    $bannerBrush.ImageSource = $bannerBitmap
    $bannerBrush.Stretch = "UniformToFill"
    $bannerBrush.AlignmentX = "Center"
    $bannerBrush.AlignmentY = "Center"
    $headerBorder.Background = $bannerBrush
} else {
    $headerBorder.Background = "#171C29"
}
$root.Children.Add($headerBorder) | Out-Null

$header = New-Object System.Windows.Controls.StackPanel
$header.VerticalAlignment = "Center"
$headerBorder.Child = $header

$title = New-Object System.Windows.Controls.TextBlock
$title.Text = "MA BIBLIOTHEQUE"
$title.FontSize = 34
$title.FontWeight = "Bold"
$title.Foreground = "#F4F7FF"
$header.Children.Add($title) | Out-Null

$subtitle = New-Object System.Windows.Controls.TextBlock
$subtitle.Text = "Tous vos jeux et logiciels, reunis au meme endroit."
$subtitle.FontSize = 14
$subtitle.Foreground = "#98A2B8"
$subtitle.Margin = "0,4,0,0"
$header.Children.Add($subtitle) | Out-Null

$searchRow = New-Object System.Windows.Controls.DockPanel
$searchRow.Margin = "0,16,0,0"
$header.Children.Add($searchRow) | Out-Null

$gameCount = New-Object System.Windows.Controls.TextBlock
$gameCount.Foreground = "#98A2B8"
$gameCount.FontSize = 14
$gameCount.VerticalAlignment = "Center"
[System.Windows.Controls.DockPanel]::SetDock($gameCount, "Right")
$searchRow.Children.Add($gameCount) | Out-Null

$searchBox = New-Object System.Windows.Controls.TextBox
$searchBox.Width = 330
$searchBox.Height = 38
$searchBox.HorizontalAlignment = "Left"
$searchBox.Padding = "12,8"
$searchBox.FontSize = 14
$searchBox.Foreground = "#F4F7FF"
$searchBox.Background = "#1C2230"
$searchBox.BorderBrush = "#343D52"
$searchBox.BorderThickness = 1
$searchBox.ToolTip = "Rechercher un jeu"
$searchPlaceholder = "Rechercher un jeu..."
$searchBox.Text = $searchPlaceholder
$searchBox.Foreground = "#7F8AA3"
[System.Windows.Controls.DockPanel]::SetDock($searchBox, "Left")
$searchRow.Children.Add($searchBox) | Out-Null

$libraryFilter = New-Object System.Windows.Controls.ComboBox
$libraryFilter.Width = 150
$libraryFilter.Height = 38
$libraryFilter.Margin = "12,0,0,0"
$libraryFilter.Padding = "10,7"
$libraryFilter.FontSize = 14
$libraryFilter.Foreground = "#111318"
$libraryFilter.Background = "#F4F7FF"
$libraryFilter.BorderBrush = "#9AA4B8"
$libraryFilter.Items.Add("Accueil") | Out-Null
$libraryFilter.Items.Add("Tout") | Out-Null
$libraryFilter.Items.Add("Jeux") | Out-Null
$libraryFilter.Items.Add("Logiciels") | Out-Null
$libraryFilter.Items.Add("Favoris") | Out-Null
$libraryFilter.Items.Add("Recents") | Out-Null
$libraryFilter.SelectedIndex = 0
[System.Windows.Controls.DockPanel]::SetDock($libraryFilter, "Left")
$searchRow.Children.Add($libraryFilter) | Out-Null

$footerBorder = New-Object System.Windows.Controls.Border
$footerBorder.Margin = "0,0,0,16"
$footerBorder.Padding = "10,8"
$footerBorder.Background = "#171D29"
$footerBorder.BorderBrush = "#2B3448"
$footerBorder.BorderThickness = 1
$footerBorder.CornerRadius = 14
[System.Windows.Controls.DockPanel]::SetDock($footerBorder, "Top")
$root.Children.Add($footerBorder) | Out-Null

$footer = New-Object System.Windows.Controls.StackPanel
$footer.Orientation = "Horizontal"
$footer.HorizontalAlignment = "Center"
$footerBorder.Child = $footer

$actionButtonStyle = [System.Windows.Markup.XamlReader]::Parse(@"
<Style xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
       xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
       TargetType="{x:Type Button}">
  <Setter Property="Template">
    <Setter.Value>
      <ControlTemplate TargetType="{x:Type Button}">
        <Border x:Name="ButtonBorder"
                Background="{TemplateBinding Background}"
                BorderBrush="{TemplateBinding BorderBrush}"
                BorderThickness="{TemplateBinding BorderThickness}"
                CornerRadius="9"
                Padding="{TemplateBinding Padding}">
          <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
        </Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True">
            <Setter TargetName="ButtonBorder" Property="Opacity" Value="0.82"/>
          </Trigger>
          <Trigger Property="IsPressed" Value="True">
            <Setter TargetName="ButtonBorder" Property="Opacity" Value="0.62"/>
          </Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate>
    </Setter.Value>
  </Setter>
</Style>
"@)

function New-ActionButton([string]$text, [string]$color) {
    $button = New-Object System.Windows.Controls.Button
    $button.Style = $actionButtonStyle
    $button.Content = $text
    $button.Height = 40
    $button.MinWidth = 92
    $button.Margin = "5,3"
    $button.Padding = "14,0"
    $button.FontSize = 13
    $button.FontWeight = "SemiBold"
    $button.Foreground = "White"
    $button.Background = $color
    $button.BorderThickness = 0
    $button.Cursor = "Hand"
    return $button
}

$fpsButton = New-ActionButton "FPS : OFF" "#B33939"
$footer.Children.Add($fpsButton) | Out-Null

$showFpsButton = New-ActionButton "AFFICHER FPS" "#0984E3"
$showFpsButton.ToolTip = "Afficher ou masquer les FPS avec l'overlay NVIDIA (Alt+R)."
$footer.Children.Add($showFpsButton) | Out-Null
$showFpsButton.Add_Click({
    try {
        $keyShell = New-Object -ComObject WScript.Shell
        Start-Sleep -Milliseconds 150
        $keyShell.SendKeys("%r")
    } catch {
        [System.Windows.MessageBox]::Show(
            "Impossible d'ouvrir l'overlay NVIDIA. Essayez Alt+R dans le jeu.",
            "Game Launcher"
        ) | Out-Null
    }
})

$autoFpsCheck = New-Object System.Windows.Controls.CheckBox
$autoFpsCheck.Content = "Auto FPS"
$autoFpsCheck.IsChecked = $true
$autoFpsCheck.Foreground = "#DCE3F3"
$autoFpsCheck.FontSize = 14
$autoFpsCheck.FontWeight = "SemiBold"
$autoFpsCheck.VerticalAlignment = "Center"
$autoFpsCheck.Margin = "10,0,8,0"
$autoFpsCheck.ToolTip = "Active automatiquement le mode FPS avant de lancer un jeu."
$footer.Children.Add($autoFpsCheck) | Out-Null

$addButton = New-ActionButton "+ AJOUTER" "#6C5CE7"
$footer.Children.Add($addButton) | Out-Null

$detectGamesButton = New-ActionButton "JEUX AUTO" "#16A085"
$detectGamesButton.ToolTip = "Detecter automatiquement les jeux du Bureau, de Steam et d'Epic Games."
$footer.Children.Add($detectGamesButton) | Out-Null

$detectSoftwareButton = New-ActionButton "LOGICIELS" "#8E44AD"
$detectSoftwareButton.ToolTip = "Ajoute automatiquement les logiciels installes sur ce PC."
$footer.Children.Add($detectSoftwareButton) | Out-Null

$updateButton = New-ActionButton "MISE A JOUR" "#E67E22"
$updateButton.ToolTip = "Telecharger et installer la derniere version sans supprimer votre liste."
$footer.Children.Add($updateButton) | Out-Null

function Check-LauncherUpdate {
    try {
        $cacheValue = [DateTime]::UtcNow.Ticks
        $manifestText = (New-Object System.Net.WebClient).DownloadString(
            "https://chevallierlucas69-png.github.io/version.json?cache=$cacheValue"
        )
        $onlineVersion = ($manifestText | ConvertFrom-Json).version
        if ([version]$onlineVersion -gt [version]$launcherVersion) {
            $updateButton.Content = "NOUVELLE VERSION !"
            $updateButton.Background = "#E74C3C"
            $updateButton.ToolTip = "La version $onlineVersion est disponible. Cliquez pour l'installer."
            if ($launcherSettings.AutoUpdate) {
                $silentUpdater = Join-Path $appDir "Lancer Mise a jour.vbs"
                if (Test-Path -LiteralPath $silentUpdater) {
                    Start-Process wscript.exe -ArgumentList "`"$silentUpdater`""
                    $window.Close()
                }
            }
        } else {
            $updateButton.Content = "A JOUR"
            $updateButton.Background = "#2D8C68"
            $updateButton.ToolTip = "Game Launcher $launcherVersion est a jour."
        }
    } catch {
        $updateButton.Content = "MISE A JOUR"
        $updateButton.Background = "#E67E22"
        $updateButton.ToolTip = "Verification impossible. Cliquez pour essayer manuellement."
    }
}

$comingSoonButton = New-ActionButton "OUTILS" "#2D6A8A"
$comingSoonButton.ToolTip = "Themes, sauvegarde, reparation et automatisation."
$footer.Children.Add($comingSoonButton) | Out-Null

$openFolderButton = New-ActionButton "DOSSIER" "#283044"
$footer.Children.Add($openFolderButton) | Out-Null
$openFolderButton.Add_Click({ Start-Process explorer.exe -ArgumentList "`"$appDir`"" })

function Update-FpsButton {
    $isEnabled = (Get-ActivePowerPlan) -eq $highPerformanceGuid
    if ($isEnabled) {
        $fpsButton.Content = "FPS : ON"
        $fpsButton.Background = "#00A884"
        $fpsButton.ToolTip = "Performances elevees actives. Cliquez pour revenir au mode normal."
    } else {
        $fpsButton.Content = "FPS : OFF"
        $fpsButton.Background = "#B33939"
        $fpsButton.ToolTip = "Cliquez pour activer les performances elevees."
    }
}

$fpsButton.Add_Click({
    $enable = (Get-ActivePowerPlan) -ne $highPerformanceGuid
    Set-FpsMode $enable
    Update-FpsButton
})

$scroll = New-Object System.Windows.Controls.ScrollViewer
$scroll.VerticalScrollBarVisibility = "Auto"
$root.Children.Add($scroll) | Out-Null

$gamePanel = New-Object System.Windows.Controls.WrapPanel
$gamePanel.Orientation = "Horizontal"
$scroll.Content = $gamePanel

function Refresh-Games {
    $gamePanel.Children.Clear()
    $allGames = @(
        Get-Games | Sort-Object `
            @{ Expression = { if ([string]$_.Category -eq "Software") { 1 } else { 0 } } }, `
            @{ Expression = { -not [bool]$_.Favorite } }, `
            Name
    )
    $selectedFilter = [string]$libraryFilter.SelectedItem
    if ($selectedFilter -eq "Favoris") {
        $filteredGames = @($allGames | Where-Object { [bool]$_.Favorite })
    } elseif ($selectedFilter -eq "Accueil") {
        $filteredGames = @(
            $allGames |
                Sort-Object `
                    @{ Expression = { -not [bool]$_.Favorite } }, `
                    @{ Expression = { if ($_.LastPlayed) { [DateTime]$_.LastPlayed } else { [DateTime]::MinValue } }; Descending = $true }, `
                    @{ Expression = { [int]$_.LaunchCount }; Descending = $true } |
                Select-Object -First 12
        )
    } elseif ($selectedFilter -eq "Recents") {
        $filteredGames = @(
            $allGames |
                Where-Object { $_.LastPlayed } |
                Sort-Object LastPlayed -Descending |
                Select-Object -First 8
        )
    } elseif ($selectedFilter -eq "Logiciels") {
        $filteredGames = @($allGames | Where-Object { [string]$_.Category -eq "Software" })
    } elseif ($selectedFilter -eq "Jeux") {
        $filteredGames = @($allGames | Where-Object { [string]$_.Category -ne "Software" })
    } else {
        $filteredGames = $allGames
    }

    $searchText = [string]$searchBox.Text
    if ($searchText -eq $searchPlaceholder) { $searchText = "" }
    if ([string]::IsNullOrWhiteSpace($searchText)) {
        $games = $filteredGames
    } else {
        $games = @($filteredGames | Where-Object { [string]$_.Name -like "*$searchText*" })
    }
    $itemWord = if ($games.Count -eq 1) { "element" } else { "elements" }
    $gameCount.Text = "$($games.Count) $itemWord sur $($allGames.Count)"

    if ($allGames.Count -eq 0) {
        $emptyCard = New-Object System.Windows.Controls.Border
        $emptyCard.Width = 540
        $emptyCard.Height = 170
        $emptyCard.Margin = "120,42,0,0"
        $emptyCard.Padding = 26
        $emptyCard.Background = "#171D29"
        $emptyCard.BorderBrush = "#343E55"
        $emptyCard.BorderThickness = 1
        $emptyCard.CornerRadius = 16

        $emptyStack = New-Object System.Windows.Controls.StackPanel
        $emptyStack.VerticalAlignment = "Center"
        $emptyCard.Child = $emptyStack

        $emptyTitle = New-Object System.Windows.Controls.TextBlock
        $emptyTitle.Text = "Votre bibliotheque est vide"
        $emptyTitle.FontSize = 23
        $emptyTitle.FontWeight = "SemiBold"
        $emptyTitle.Foreground = "#F4F7FF"
        $emptyTitle.HorizontalAlignment = "Center"
        $emptyStack.Children.Add($emptyTitle) | Out-Null

        $emptyText = New-Object System.Windows.Controls.TextBlock
        $emptyText.Text = "Ajoutez un jeu ou cliquez sur LOGICIELS pour detecter vos applications."
        $emptyText.FontSize = 14
        $emptyText.Foreground = "#94A0B8"
        $emptyText.TextAlignment = "Center"
        $emptyText.TextWrapping = "Wrap"
        $emptyText.Margin = "20,12,20,0"
        $emptyStack.Children.Add($emptyText) | Out-Null
        $gamePanel.Children.Add($emptyCard) | Out-Null
        return
    }

    if ($games.Count -eq 0) {
        $empty = New-Object System.Windows.Controls.TextBlock
        $empty.Text = "Aucun jeu ne correspond a votre recherche."
        $empty.FontSize = 18
        $empty.Foreground = "#7F8AA3"
        $empty.Margin = "8,40,0,0"
        $gamePanel.Children.Add($empty) | Out-Null
        return
    }

    $currentSection = ""
    foreach ($game in $games) {
        $sectionName = if ([string]$game.Category -eq "Software") { "LOGICIELS" } else { "JEUX" }
        if ($sectionName -ne $currentSection) {
            $currentSection = $sectionName
            $sectionHeader = New-Object System.Windows.Controls.Border
            $sectionHeader.Width = 950
            $sectionHeader.Height = 42
            $sectionHeader.Margin = "8,10,8,2"
            $sectionHeader.Padding = "14,0"
            $sectionHeader.Background = if ($sectionName -eq "JEUX") { "#162B32" } else { "#261D3A" }
            $sectionHeader.BorderBrush = if ($sectionName -eq "JEUX") { "#16A085" } else { "#8E44AD" }
            $sectionHeader.BorderThickness = "4,0,0,0"
            $sectionHeader.CornerRadius = 8

            $sectionText = New-Object System.Windows.Controls.TextBlock
            $sectionText.Text = $sectionName
            $sectionText.Foreground = "#F4F7FF"
            $sectionText.FontSize = 15
            $sectionText.FontWeight = "Bold"
            $sectionText.VerticalAlignment = "Center"
            $sectionHeader.Child = $sectionText
            $gamePanel.Children.Add($sectionHeader) | Out-Null
        }

        $cardColors = @("#6C5CE7", "#0984E3", "#00A884", "#D35400", "#C0392B", "#8E44AD")
        $cardColorIndex = ([string]$game.Name).Length % $cardColors.Count
        $cardAccent = $cardColors[$cardColorIndex]

        $card = New-Object System.Windows.Controls.Border
        $card.Width = 245
        $card.Height = 154
        $card.Margin = 8
        $card.Padding = 15
        $card.Background = "#1C2230"
        $card.CornerRadius = 10
        $card.BorderBrush = $cardAccent
        $card.BorderThickness = "3,1,1,1"
        $card.Tag = $cardAccent
        $card.Add_MouseEnter({
            param($sender, $eventArgs)
            $sender.Background = "#252D3E"
            $sender.BorderBrush = "#6654B8"
        })
        $card.Add_MouseLeave({
            param($sender, $eventArgs)
            $sender.Background = "#1C2230"
            $sender.BorderBrush = [string]$sender.Tag
        })
        if ($game.LastPlayed) {
            $lastPlayedText = ([DateTime]$game.LastPlayed).ToString("dd/MM/yyyy HH:mm")
            $card.ToolTip = "$($game.Path)`nDernier lancement : $lastPlayedText"
        } else {
            $card.ToolTip = [string]$game.Path
        }
        if ($game.Description) {
            $card.ToolTip = "$($card.ToolTip)`n`n$($game.Description)"
        }

        $cardMenu = New-Object System.Windows.Controls.ContextMenu
        $descriptionItem = New-Object System.Windows.Controls.MenuItem
        $descriptionItem.Header = "Modifier la description"
        $descriptionItem.Tag = [string]$game.Path
        $descriptionItem.Add_Click({
            param($sender, $eventArgs)
            $path = [string]$sender.Tag
            $items = @(Get-Games)
            $selected = $items | Where-Object { [string]$_.Path -eq $path } | Select-Object -First 1
            $description = [Microsoft.VisualBasic.Interaction]::InputBox(
                "Description du jeu ou logiciel :",
                "Game Launcher",
                [string]$selected.Description
            )
            if (-not [string]::IsNullOrWhiteSpace($description)) {
                $selected | Add-Member -NotePropertyName "Description" -NotePropertyValue $description -Force
                Save-Games $items
                Refresh-Games
            }
        })
        $cardMenu.Items.Add($descriptionItem) | Out-Null

        $bannerItem = New-Object System.Windows.Controls.MenuItem
        $bannerItem.Header = "Choisir une grande image"
        $bannerItem.Tag = [string]$game.Path
        $bannerItem.Add_Click({
            param($sender, $eventArgs)
            $path = [string]$sender.Tag
            $bannerDialog = New-Object System.Windows.Forms.OpenFileDialog
            $bannerDialog.Filter = "Images (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"
            if ($bannerDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                $items = @(Get-Games)
                foreach ($item in $items) {
                    if ([string]$item.Path -eq $path) {
                        $item | Add-Member -NotePropertyName "BannerPath" -NotePropertyValue $bannerDialog.FileName -Force
                    }
                }
                Save-Games $items
                Refresh-Games
            }
        })
        $cardMenu.Items.Add($bannerItem) | Out-Null
        $card.ContextMenu = $cardMenu

        $cardContent = New-Object System.Windows.Controls.DockPanel
        $card.Child = $cardContent

        $gameHeader = New-Object System.Windows.Controls.StackPanel
        $gameHeader.Orientation = "Horizontal"
        $gameHeader.Margin = "0,0,0,12"
        [System.Windows.Controls.DockPanel]::SetDock($gameHeader, "Top")

        $iconPath = if ($game.BannerPath -and (Test-Path -LiteralPath $game.BannerPath)) {
            [string]$game.BannerPath
        } else {
            Get-GameIcon ([string]$game.Path)
        }
        $iconAdded = $false
        if ($iconPath) {
            try {
                $image = New-Object System.Windows.Controls.Image
                $image.Width = if ($game.BannerPath) { 68 } else { 42 }
                $image.Height = 42
                $image.Margin = "0,0,11,0"
                $image.Stretch = "Uniform"
                $bitmap = New-Object System.Windows.Media.Imaging.BitmapImage
                $bitmap.BeginInit()
                $bitmap.CacheOption = "OnLoad"
                $bitmap.UriSource = New-Object System.Uri -ArgumentList $iconPath
                $bitmap.EndInit()
                $image.Source = $bitmap
                $gameHeader.Children.Add($image) | Out-Null
                $iconAdded = $true
            } catch {}
        }

        if (-not $iconAdded) {
            $fallbackIcon = New-Object System.Windows.Controls.Border
            $fallbackIcon.Width = 42
            $fallbackIcon.Height = 42
            $fallbackIcon.Margin = "0,0,11,0"
            $fallbackIcon.Background = $cardAccent
            $fallbackIcon.CornerRadius = 10

            $initial = New-Object System.Windows.Controls.TextBlock
            $initial.Text = ([string]$game.Name).Substring(0,1).ToUpperInvariant()
            $initial.Foreground = "White"
            $initial.FontSize = 20
            $initial.FontWeight = "Bold"
            $initial.HorizontalAlignment = "Center"
            $initial.VerticalAlignment = "Center"
            $fallbackIcon.Child = $initial
            $gameHeader.Children.Add($fallbackIcon) | Out-Null
        }

        $nameStack = New-Object System.Windows.Controls.StackPanel
        $nameStack.VerticalAlignment = "Center"

        $name = New-Object System.Windows.Controls.TextBlock
        $name.Text = [string]$game.Name
        $name.FontSize = 17
        $name.FontWeight = "SemiBold"
        $name.Foreground = "#F4F7FF"
        $name.TextTrimming = "CharacterEllipsis"
        $name.VerticalAlignment = "Center"
        $name.MaxWidth = 140
        $nameStack.Children.Add($name) | Out-Null

        $gameType = New-Object System.Windows.Controls.TextBlock
        $extension = [System.IO.Path]::GetExtension([string]$game.Path).ToLowerInvariant()
        if ($extension -eq ".url") {
            $gameType.Text = "Steam / Launcher"
        } elseif ($extension -eq ".lnk") {
            $gameType.Text = "Raccourci Windows"
        } else {
            $gameType.Text = "Application"
        }
        $gameType.Foreground = "#8490A8"
        $gameType.FontSize = 10
        $gameType.Margin = "0,4,0,0"
        $nameStack.Children.Add($gameType) | Out-Null

        $gameStats = New-Object System.Windows.Controls.TextBlock
        if ($game.LastPlayed) {
            $playedDate = ([DateTime]$game.LastPlayed).ToString("dd/MM HH:mm")
            $displayLaunchCount = [math]::Max(1, [int]$game.LaunchCount)
            $launchLabel = if ($displayLaunchCount -eq 1) { "1 lancement" } else { "$displayLaunchCount lancements" }
            $timeLabel = Format-PlayTime ([double]$game.PlayTimeSeconds)
            $gameStats.Text = "$playedDate - $launchLabel - $timeLabel"
        } else {
            $gameStats.Text = "Jamais lance"
        }
        $gameStats.Foreground = "#68758F"
        $gameStats.FontSize = 9
        $gameStats.Margin = "0,3,0,0"
        $nameStack.Children.Add($gameStats) | Out-Null
        $gameHeader.Children.Add($nameStack) | Out-Null
        $cardContent.Children.Add($gameHeader) | Out-Null

        $buttonRow = New-Object System.Windows.Controls.StackPanel
        $buttonRow.Orientation = "Horizontal"
        $buttonRow.VerticalAlignment = "Bottom"
        [System.Windows.Controls.DockPanel]::SetDock($buttonRow, "Bottom")

        $launch = New-Object System.Windows.Controls.Button
        $isSoftwareCard = [string]$game.Category -eq "Software"
        $launch.Content = if ($isSoftwareCard) { "OUVRIR" } else { "JOUER" }
        $launch.Tag = [string]$game.Path
        $launch.Width = 92
        $launch.Height = 34
        $launch.Foreground = "White"
        $launch.Background = "#00B894"
        $launch.BorderThickness = 0
        $launch.FontWeight = "Bold"
        $launch.Cursor = "Hand"
        $launch.Add_Click({
            param($sender, $eventArgs)
            $target = [string]$sender.Tag
            Register-GameLaunch $target
            Start-Game $target
            Refresh-Games
        })
        $buttonRow.Children.Add($launch) | Out-Null

        $favorite = New-Object System.Windows.Controls.Button
        $favorite.Content = if ([bool]$game.Favorite) { [char]9733 } else { [char]9734 }
        $favorite.Tag = [string]$game.Path
        $favorite.ToolTip = "Ajouter ou retirer des favoris"
        $favorite.Width = 32
        $favorite.Height = 30
        $favorite.Margin = "8,0,0,0"
        $favorite.Foreground = if ([bool]$game.Favorite) { "#FFD166" } else { "#AAB4CA" }
        $favorite.Background = "Transparent"
        $favorite.BorderBrush = "#46516A"
        $favorite.BorderThickness = 1
        $favorite.FontSize = 18
        $favorite.FontWeight = "Bold"
        $favorite.Cursor = "Hand"
        $favorite.Add_Click({
            param($sender, $eventArgs)
            Toggle-GameFavorite ([string]$sender.Tag)
            Refresh-Games
        })
        $buttonRow.Children.Add($favorite) | Out-Null

        $perGameFps = New-Object System.Windows.Controls.Button
        $fpsEnabledForCard = if ($null -eq $game.FpsEnabled) { $true } else { [bool]$game.FpsEnabled }
        $perGameFps.Content = if ($fpsEnabledForCard) { "FPS" } else { "ECO" }
        $perGameFps.Tag = [string]$game.Path
        $perGameFps.ToolTip = "Activer ou desactiver le mode FPS automatique pour cet element."
        $perGameFps.Width = 34
        $perGameFps.Height = 30
        $perGameFps.Margin = "6,0,0,0"
        $perGameFps.Foreground = "White"
        $perGameFps.Background = if ($fpsEnabledForCard) { "#167C68" } else { "#596275" }
        $perGameFps.BorderThickness = 0
        $perGameFps.FontSize = 9
        $perGameFps.FontWeight = "Bold"
        $perGameFps.Cursor = "Hand"
        $perGameFps.Add_Click({
            param($sender, $eventArgs)
            $path = [string]$sender.Tag
            $items = @(Get-Games)
            foreach ($item in $items) {
                if ([string]$item.Path -eq $path) {
                    $current = if ($null -eq $item.FpsEnabled) { $true } else { [bool]$item.FpsEnabled }
                    $item | Add-Member -NotePropertyName "FpsEnabled" -NotePropertyValue (-not $current) -Force
                }
            }
            Save-Games $items
            Refresh-Games
        })
        $buttonRow.Children.Add($perGameFps) | Out-Null

        $remove = New-Object System.Windows.Controls.Button
        $remove.Content = "X"
        $remove.Tag = [string]$game.Path
        $remove.ToolTip = "Retirer ce jeu"
        $remove.Width = 26
        $remove.Height = 30
        $remove.Margin = "8,0,0,0"
        $remove.Foreground = "#FF7675"
        $remove.Background = "Transparent"
        $remove.BorderThickness = 0
        $remove.FontSize = 14
        $remove.Cursor = "Hand"
        $remove.Add_Click({
            param($sender, $eventArgs)
            $pathToRemove = [string]$sender.Tag
            $answer = [System.Windows.MessageBox]::Show(
                "Retirer cet element du launcher ?",
                "Game Launcher",
                "YesNo",
                "Question"
            )
            if ($answer -ne "Yes") { return }
            $remaining = @(Get-Games | Where-Object { [string]$_.Path -ne $pathToRemove })
            Save-Games $remaining
            Refresh-Games
        })
        $buttonRow.Children.Add($remove) | Out-Null
        $cardContent.Children.Add($buttonRow) | Out-Null
        $gamePanel.Children.Add($card) | Out-Null
    }
}

$addButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = "Choisissez le jeu ou son raccourci"
    $dialog.Filter = "Jeux et raccourcis (*.exe;*.lnk;*.url)|*.exe;*.lnk;*.url|Tous les fichiers (*.*)|*.*"
    $dialog.Multiselect = $false

    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $games = @(Get-Games)
        if ($games.Path -contains $dialog.FileName) {
            [System.Windows.MessageBox]::Show("Ce jeu est deja dans la liste.", "Game Launcher") | Out-Null
            return
        }

        $displayName = [System.IO.Path]::GetFileNameWithoutExtension($dialog.FileName)
        $games += [PSCustomObject]@{
            Name = $displayName
            Path = $dialog.FileName
            Category = "Game"
        }
        Save-Games $games
        Refresh-Games
    }
})

$detectSoftwareButton.Add_Click({
    $added = Add-DetectedSoftware
    $libraryFilter.SelectedItem = "Logiciels"
    Refresh-Games
    $message = if ($added -eq 0) {
        "Aucun nouveau logiciel detecte."
    } elseif ($added -eq 1) {
        "1 logiciel ajoute au launcher."
    } else {
        "$added logiciels ajoutes au launcher."
    }
    [System.Windows.MessageBox]::Show($message, "Detection terminee") | Out-Null
})

$detectGamesButton.Add_Click({
    $added = Add-DetectedGames
    $libraryFilter.SelectedItem = "Jeux"
    Refresh-Games
    $message = if ($added -eq 0) {
        "Aucun nouveau jeu detecte."
    } elseif ($added -eq 1) {
        "1 jeu ajoute au launcher."
    } else {
        "$added jeux ajoutes au launcher."
    }
    [System.Windows.MessageBox]::Show($message, "Detection terminee") | Out-Null
})

$updateButton.Add_Click({
    $updaterPath = Join-Path $appDir "Updater.ps1"
    if (-not (Test-Path -LiteralPath $updaterPath)) {
        [System.Windows.MessageBox]::Show(
            "Le module de mise a jour est absent. Reinstallez une fois le launcher depuis le site.",
            "Game Launcher",
            "OK",
            "Warning"
        ) | Out-Null
        return
    }
    $answer = [System.Windows.MessageBox]::Show(
        "Rechercher et installer la derniere version ?`nVotre liste de jeux sera conservee.",
        "Mise a jour - version $launcherVersion",
        "YesNo",
        "Question"
    )
    if ($answer -ne "Yes") { return }
    $updateLauncher = Join-Path $appDir "Lancer Mise a jour.vbs"
    if (Test-Path -LiteralPath $updateLauncher) {
        Start-Process wscript.exe -ArgumentList "`"$updateLauncher`""
    } else {
        Start-Process powershell.exe -ArgumentList @(
            "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
            "-File", "`"$updaterPath`"", "-InstallDir", "`"$appDir`""
        )
    }
    $window.Close()
})

function Apply-LauncherTheme([string]$theme) {
    $launcherSettings.Theme = $theme
    switch ($theme) {
        "Bleu" { $window.Background = "#07131F"; $footerBorder.Background = "#102231" }
        "Rouge" { $window.Background = "#190B10"; $footerBorder.Background = "#29141B" }
        default { $window.Background = "#10131A"; $footerBorder.Background = "#171D29" }
    }
    if ($theme -ne "Personnalise") { $launcherSettings.CustomBackground = "" }
    Save-LauncherSettings $launcherSettings
}

function Repair-AllLibraryItems {
    $items = @(Get-Games)
    $repaired = 0
    foreach ($item in $items) {
        if (Test-Path -LiteralPath ([string]$item.Path)) { continue }
        $newPath = Find-MovedLibraryItem ([string]$item.Path)
        if ($newPath) { $item.Path = $newPath; $repaired++ }
    }
    Save-Games $items
    Refresh-Games
    [System.Windows.MessageBox]::Show("$repaired raccourci(s) repare(s).", "Reparation terminee") | Out-Null
}

$toolsMenu = New-Object System.Windows.Controls.ContextMenu
foreach ($themeName in @("Violet", "Bleu", "Rouge")) {
    $themeItem = New-Object System.Windows.Controls.MenuItem
    $themeItem.Header = "Theme $themeName"
    $themeItem.Tag = $themeName
    $themeItem.Add_Click({
        param($sender, $eventArgs)
        Apply-LauncherTheme ([string]$sender.Tag)
    })
    $toolsMenu.Items.Add($themeItem) | Out-Null
}

$customThemeItem = New-Object System.Windows.Controls.MenuItem
$customThemeItem.Header = "Fond personnalise..."
$customThemeItem.Add_Click({
    $imageDialog = New-Object System.Windows.Forms.OpenFileDialog
    $imageDialog.Filter = "Images (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"
    if ($imageDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        try {
            $backgroundBrush = New-Object System.Windows.Media.ImageBrush
            $backgroundBrush.ImageSource = New-Object System.Windows.Media.Imaging.BitmapImage(
                (New-Object System.Uri -ArgumentList $imageDialog.FileName)
            )
            $backgroundBrush.Stretch = "UniformToFill"
            $backgroundBrush.Opacity = 0.28
            $window.Background = $backgroundBrush
            $launcherSettings.Theme = "Personnalise"
            $launcherSettings.CustomBackground = $imageDialog.FileName
            Save-LauncherSettings $launcherSettings
        } catch {}
    }
})
$toolsMenu.Items.Add($customThemeItem) | Out-Null

$backupItem = New-Object System.Windows.Controls.MenuItem
$backupItem.Header = "Sauvegarder la bibliotheque"
$backupItem.Add_Click({
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    Copy-Item -LiteralPath $gamesFile -Destination $backupGamesFile -Force
    [System.Windows.MessageBox]::Show("Sauvegarde terminee dans Documents.", "Game Launcher") | Out-Null
})
$toolsMenu.Items.Add($backupItem) | Out-Null

$restoreItem = New-Object System.Windows.Controls.MenuItem
$restoreItem.Header = "Restaurer la sauvegarde"
$restoreItem.Add_Click({
    if (Test-Path -LiteralPath $backupGamesFile) {
        Copy-Item -LiteralPath $backupGamesFile -Destination $gamesFile -Force
        Refresh-Games
        [System.Windows.MessageBox]::Show("Bibliotheque restauree.", "Game Launcher") | Out-Null
    } else {
        [System.Windows.MessageBox]::Show("Aucune sauvegarde trouvee.", "Game Launcher") | Out-Null
    }
})
$toolsMenu.Items.Add($restoreItem) | Out-Null

$repairItem = New-Object System.Windows.Controls.MenuItem
$repairItem.Header = "Reparer tous les raccourcis"
$repairItem.Add_Click({ Repair-AllLibraryItems })
$toolsMenu.Items.Add($repairItem) | Out-Null

$autoUpdateItem = New-Object System.Windows.Controls.MenuItem
$autoUpdateItem.Header = "Mise a jour silencieuse"
$autoUpdateItem.IsCheckable = $true
$autoUpdateItem.IsChecked = [bool]$launcherSettings.AutoUpdate
$autoUpdateItem.Add_Click({
    $launcherSettings.AutoUpdate = [bool]$autoUpdateItem.IsChecked
    Save-LauncherSettings $launcherSettings
})
$toolsMenu.Items.Add($autoUpdateItem) | Out-Null

$comingSoonButton.ContextMenu = $toolsMenu
$comingSoonButton.Add_Click({
    $toolsMenu.PlacementTarget = $comingSoonButton
    $toolsMenu.IsOpen = $true
})

$searchBox.Add_GotKeyboardFocus({
    if ($searchBox.Text -eq $searchPlaceholder) {
        $searchBox.Text = ""
        $searchBox.Foreground = "#F4F7FF"
    }
})
$searchBox.Add_LostKeyboardFocus({
    if ([string]::IsNullOrWhiteSpace($searchBox.Text)) {
        $searchBox.Text = $searchPlaceholder
        $searchBox.Foreground = "#7F8AA3"
    }
})
$searchBox.Add_TextChanged({ Refresh-Games })
$libraryFilter.Add_SelectionChanged({ Refresh-Games })

$performanceTimer = New-Object System.Windows.Threading.DispatcherTimer
$performanceTimer.Interval = [TimeSpan]::FromSeconds(4)
$performanceTimer.Add_Tick({ Optimize-RetracProcesses })
$performanceTimer.Start()

$updateCheckTimer = New-Object System.Windows.Threading.DispatcherTimer
$updateCheckTimer.Interval = [TimeSpan]::FromSeconds(2)
$updateCheckTimer.Add_Tick({
    $updateCheckTimer.Stop()
    Check-LauncherUpdate
})
$updateCheckTimer.Start()

$playTimeTimer = New-Object System.Windows.Threading.DispatcherTimer
$playTimeTimer.Interval = [TimeSpan]::FromSeconds(5)
$playTimeTimer.Add_Tick({ Update-PlaySessions })
$playTimeTimer.Start()

if ($launcherSettings.Theme -eq "Personnalise" -and
    $launcherSettings.CustomBackground -and
    (Test-Path -LiteralPath $launcherSettings.CustomBackground)) {
    try {
        $savedBackground = New-Object System.Windows.Media.ImageBrush
        $savedBackground.ImageSource = New-Object System.Windows.Media.Imaging.BitmapImage(
            (New-Object System.Uri -ArgumentList $launcherSettings.CustomBackground)
        )
        $savedBackground.Stretch = "UniformToFill"
        $savedBackground.Opacity = 0.28
        $window.Background = $savedBackground
    } catch {}
} else {
    Apply-LauncherTheme ([string]$launcherSettings.Theme)
}

Update-FpsButton
Add-DetectedSoftware | Out-Null
Refresh-Games
$window.ShowDialog() | Out-Null

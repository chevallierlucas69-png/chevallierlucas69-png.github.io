Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Windows.Forms

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class GameLauncherIdentity {
    [DllImport("shell32.dll", SetLastError = true)]
    public static extern int SetCurrentProcessExplicitAppUserModelID(
        [MarshalAs(UnmanagedType.LPWStr)] string appID
    );
}
"@
[GameLauncherIdentity]::SetCurrentProcessExplicitAppUserModelID("Lucas.GameLauncher") | Out-Null

$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$gamesFile = Join-Path $appDir "games.json"
$normalPowerPlanFile = Join-Path $appDir "normal-power-plan.txt"
$highPerformanceGuid = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"

function Get-Games {
    if (-not (Test-Path -LiteralPath $gamesFile)) { return @() }
    try {
        $items = Get-Content -LiteralPath $gamesFile -Raw | ConvertFrom-Json
        return @($items)
    } catch {
        [System.Windows.MessageBox]::Show(
            "La liste des jeux est illisible. Elle va etre recreee.",
            "Game Launcher"
        ) | Out-Null
        return @()
    }
}

function Save-Games([array]$games) {
    $games | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $gamesFile -Encoding UTF8
}

function Get-ActivePowerPlan {
    $result = powercfg /getactivescheme 2>$null
    $match = [regex]::Match(($result -join " "), "[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")
    if ($match.Success) { return $match.Value.ToLowerInvariant() }
    return ""
}

function Set-FpsMode([bool]$enabled) {
    try {
        if ($enabled) {
            $currentPlan = Get-ActivePowerPlan
            if ($currentPlan -and $currentPlan -ne $highPerformanceGuid) {
                Set-Content -LiteralPath $normalPowerPlanFile -Value $currentPlan -Encoding ASCII
            }
            powercfg /setactive SCHEME_MIN | Out-Null
            New-Item -Path "HKCU:\Software\Microsoft\GameBar" -Force | Out-Null
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Type DWord -Value 1
        } else {
            $normalPlan = "381b4222-f694-41f0-9685-ff5bb260df2e"
            if (Test-Path -LiteralPath $normalPowerPlanFile) {
                $savedPlan = (Get-Content -LiteralPath $normalPowerPlanFile -Raw).Trim()
                if ($savedPlan -match "^[0-9a-fA-F-]{36}$") { $normalPlan = $savedPlan }
            }
            powercfg /setactive $normalPlan | Out-Null
        }
    } catch {
        [System.Windows.MessageBox]::Show(
            "Le mode FPS ne peut pas etre modifie.`n`n$($_.Exception.Message)",
            "Game Launcher",
            "OK",
            "Error"
        ) | Out-Null
    }
}

function Optimize-RetracProcesses {
    if ((Get-ActivePowerPlan) -ne $highPerformanceGuid) { return }

    $targets = Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -ieq "retrac" -or
        $_.ProcessName -like "FortniteClient-Win64-Shipping*"
    }
    foreach ($process in $targets) {
        try {
            if ($process.PriorityClass -in @("Idle", "BelowNormal", "Normal")) {
                $process.PriorityClass = "AboveNormal"
            }
        } catch {}
    }
}

function Start-RetracFpsMonitor {
    $monitorPath = Join-Path $appDir "RetracFpsMonitor.ps1"
    if (-not (Test-Path -LiteralPath $monitorPath)) { return }

    $alreadyRunning = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -eq "powershell.exe" -and $_.CommandLine -like "*RetracFpsMonitor.ps1*" } |
        Select-Object -First 1
    if ($alreadyRunning) { return }

    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = "powershell.exe"
    $startInfo.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$monitorPath`" -NormalPlanFile `"$normalPowerPlanFile`""
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
    [System.Diagnostics.Process]::Start($startInfo) | Out-Null
}

function Start-Game([string]$target) {
    if (-not (Test-Path -LiteralPath $target)) {
        [System.Windows.MessageBox]::Show(
            "Fichier introuvable :`n$target",
            "Impossible de lancer le jeu",
            "OK",
            "Warning"
        ) | Out-Null
        return
    }

    try {
        if ($autoFpsCheck -and $autoFpsCheck.IsChecked) {
            Set-FpsMode $true
            Update-FpsButton
            if ([System.IO.Path]::GetFileName($target) -ieq "retrac.exe") {
                Start-RetracFpsMonitor
            }
        }

        if ([System.IO.Path]::GetExtension($target) -ieq ".url") {
            $urlLine = Get-Content -LiteralPath $target |
                Where-Object { $_ -like "URL=*" } |
                Select-Object -First 1
            if (-not $urlLine) { throw "Adresse Steam absente du raccourci." }
            $launchTarget = $urlLine.Substring(4)
            Start-Process -FilePath $launchTarget
        } else {
            $gameProcess = Start-Process -FilePath $target -PassThru
            Start-Sleep -Milliseconds 500
            try {
                if ($gameProcess -and -not $gameProcess.HasExited) {
                    $gameProcess.PriorityClass = "High"
                }
            } catch {}
        }
    } catch {
        [System.Windows.MessageBox]::Show(
            "Le jeu ne peut pas etre lance.`n`n$($_.Exception.Message)",
            "Game Launcher",
            "OK",
            "Error"
        ) | Out-Null
    }
}

function Get-GameIcon([string]$target) {
    if ([System.IO.Path]::GetExtension($target) -ieq ".url") {
        $iconLine = Get-Content -LiteralPath $target |
            Where-Object { $_ -like "IconFile=*" } |
            Select-Object -First 1
        if ($iconLine) {
            $iconPath = $iconLine.Substring(9)
            if (Test-Path -LiteralPath $iconPath) { return $iconPath }
        }
    }

    if ([System.IO.Path]::GetExtension($target) -ieq ".exe") {
        return $target
    }
    return $null
}

$window = New-Object System.Windows.Window
$window.Title = "Game Launcher"
$window.Width = 1040
$window.Height = 680
$window.MinWidth = 720
$window.MinHeight = 480
$window.WindowStartupLocation = "CenterScreen"
$window.Background = "#10131A"
$windowIconPath = Join-Path $appDir "game-launcher.ico"
if (Test-Path -LiteralPath $windowIconPath) {
    try {
        $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create(
            (New-Object System.Uri -ArgumentList $windowIconPath)
        )
    } catch {}
}

$root = New-Object System.Windows.Controls.DockPanel
$root.Margin = 22
$window.Content = $root

$headerBorder = New-Object System.Windows.Controls.Border
$headerBorder.Height = 190
$headerBorder.Padding = 24
$headerBorder.Margin = "0,0,0,18"
$headerBorder.CornerRadius = 14
$headerBorder.BorderBrush = "#493B86"
$headerBorder.BorderThickness = 1
[System.Windows.Controls.DockPanel]::SetDock($headerBorder, "Top")

$bannerPath = Join-Path $appDir "launcher-banner.png"
if (Test-Path -LiteralPath $bannerPath) {
    $bannerBitmap = New-Object System.Windows.Media.Imaging.BitmapImage
    $bannerBitmap.BeginInit()
    $bannerBitmap.CacheOption = "OnLoad"
    $bannerBitmap.UriSource = New-Object System.Uri -ArgumentList $bannerPath
    $bannerBitmap.EndInit()
    $bannerBrush = New-Object System.Windows.Media.ImageBrush
    $bannerBrush.ImageSource = $bannerBitmap
    $bannerBrush.Stretch = "UniformToFill"
    $bannerBrush.AlignmentX = "Center"
    $bannerBrush.AlignmentY = "Center"
    $headerBorder.Background = $bannerBrush
} else {
    $headerBorder.Background = "#171C29"
}
$root.Children.Add($headerBorder) | Out-Null

$header = New-Object System.Windows.Controls.StackPanel
$header.VerticalAlignment = "Center"
$headerBorder.Child = $header

$title = New-Object System.Windows.Controls.TextBlock
$title.Text = "MES JEUX"
$title.FontSize = 34
$title.FontWeight = "Bold"
$title.Foreground = "#F4F7FF"
$header.Children.Add($title) | Out-Null

$subtitle = New-Object System.Windows.Controls.TextBlock
$subtitle.Text = "Ajoutez vos jeux puis lancez-les en un clic."
$subtitle.FontSize = 14
$subtitle.Foreground = "#98A2B8"
$subtitle.Margin = "0,4,0,0"
$header.Children.Add($subtitle) | Out-Null

$searchRow = New-Object System.Windows.Controls.DockPanel
$searchRow.Margin = "0,16,0,0"
$header.Children.Add($searchRow) | Out-Null

$gameCount = New-Object System.Windows.Controls.TextBlock
$gameCount.Foreground = "#98A2B8"
$gameCount.FontSize = 14
$gameCount.VerticalAlignment = "Center"
[System.Windows.Controls.DockPanel]::SetDock($gameCount, "Right")
$searchRow.Children.Add($gameCount) | Out-Null

$searchBox = New-Object System.Windows.Controls.TextBox
$searchBox.Width = 330
$searchBox.Height = 38
$searchBox.HorizontalAlignment = "Left"
$searchBox.Padding = "12,8"
$searchBox.FontSize = 14
$searchBox.Foreground = "#F4F7FF"
$searchBox.Background = "#1C2230"
$searchBox.BorderBrush = "#343D52"
$searchBox.BorderThickness = 1
$searchBox.ToolTip = "Rechercher un jeu"
$searchRow.Children.Add($searchBox) | Out-Null

$footer = New-Object System.Windows.Controls.StackPanel
$footer.Orientation = "Horizontal"
$footer.HorizontalAlignment = "Right"
$footer.Margin = "0,18,0,0"
[System.Windows.Controls.DockPanel]::SetDock($footer, "Bottom")
$root.Children.Add($footer) | Out-Null

function New-ActionButton([string]$text, [string]$color) {
    $button = New-Object System.Windows.Controls.Button
    $button.Content = $text
    $button.Height = 42
    $button.MinWidth = 130
    $button.Margin = "8,0,0,0"
    $button.Padding = "18,0"
    $button.FontSize = 14
    $button.FontWeight = "SemiBold"
    $button.Foreground = "White"
    $button.Background = $color
    $button.BorderThickness = 0
    $button.Cursor = "Hand"
    return $button
}

$fpsButton = New-ActionButton "MODE FPS : OFF" "#B33939"
$footer.Children.Add($fpsButton) | Out-Null

$autoFpsCheck = New-Object System.Windows.Controls.CheckBox
$autoFpsCheck.Content = "Auto FPS"
$autoFpsCheck.IsChecked = $true
$autoFpsCheck.Foreground = "#DCE3F3"
$autoFpsCheck.FontSize = 14
$autoFpsCheck.FontWeight = "SemiBold"
$autoFpsCheck.VerticalAlignment = "Center"
$autoFpsCheck.Margin = "16,0,8,0"
$autoFpsCheck.ToolTip = "Active automatiquement le mode FPS avant de lancer un jeu."
$footer.Children.Add($autoFpsCheck) | Out-Null

$addButton = New-ActionButton "+ Ajouter un jeu" "#6C5CE7"
$footer.Children.Add($addButton) | Out-Null

$openFolderButton = New-ActionButton "Ouvrir le dossier" "#283044"
$footer.Children.Add($openFolderButton) | Out-Null
$openFolderButton.Add_Click({ Start-Process explorer.exe -ArgumentList "`"$appDir`"" })

function Update-FpsButton {
    $isEnabled = (Get-ActivePowerPlan) -eq $highPerformanceGuid
    if ($isEnabled) {
        $fpsButton.Content = "MODE FPS : ON"
        $fpsButton.Background = "#00A884"
        $fpsButton.ToolTip = "Performances elevees actives. Cliquez pour revenir au mode normal."
    } else {
        $fpsButton.Content = "MODE FPS : OFF"
        $fpsButton.Background = "#B33939"
        $fpsButton.ToolTip = "Cliquez pour activer les performances elevees."
    }
}

$fpsButton.Add_Click({
    $enable = (Get-ActivePowerPlan) -ne $highPerformanceGuid
    Set-FpsMode $enable
    Update-FpsButton
})

$scroll = New-Object System.Windows.Controls.ScrollViewer
$scroll.VerticalScrollBarVisibility = "Auto"
$root.Children.Add($scroll) | Out-Null

$gamePanel = New-Object System.Windows.Controls.WrapPanel
$gamePanel.Orientation = "Horizontal"
$scroll.Content = $gamePanel

function Refresh-Games {
    $gamePanel.Children.Clear()
    $allGames = @(Get-Games | Sort-Object Name)
    $searchText = [string]$searchBox.Text
    if ([string]::IsNullOrWhiteSpace($searchText)) {
        $games = $allGames
    } else {
        $games = @($allGames | Where-Object { [string]$_.Name -like "*$searchText*" })
    }
    $gameCount.Text = "$($games.Count) jeu(x) affiche(s) sur $($allGames.Count)"

    if ($allGames.Count -eq 0) {
        $empty = New-Object System.Windows.Controls.TextBlock
        $empty.Text = "Aucun jeu pour le moment.`nCliquez sur Ajouter un jeu."
        $empty.FontSize = 18
        $empty.LineHeight = 30
        $empty.Foreground = "#7F8AA3"
        $empty.Margin = "8,40,0,0"
        $gamePanel.Children.Add($empty) | Out-Null
        return
    }

    if ($games.Count -eq 0) {
        $empty = New-Object System.Windows.Controls.TextBlock
        $empty.Text = "Aucun jeu ne correspond a votre recherche."
        $empty.FontSize = 18
        $empty.Foreground = "#7F8AA3"
        $empty.Margin = "8,40,0,0"
        $gamePanel.Children.Add($empty) | Out-Null
        return
    }

    foreach ($game in $games) {
        $card = New-Object System.Windows.Controls.Border
        $card.Width = 245
        $card.Height = 132
        $card.Margin = 8
        $card.Padding = 15
        $card.Background = "#1C2230"
        $card.CornerRadius = 10
        $card.BorderBrush = "#293247"
        $card.BorderThickness = 1
        $card.ToolTip = [string]$game.Path

        $cardContent = New-Object System.Windows.Controls.DockPanel
        $card.Child = $cardContent

        $gameHeader = New-Object System.Windows.Controls.StackPanel
        $gameHeader.Orientation = "Horizontal"
        $gameHeader.Margin = "0,0,0,12"
        [System.Windows.Controls.DockPanel]::SetDock($gameHeader, "Top")

        $iconPath = Get-GameIcon ([string]$game.Path)
        if ($iconPath) {
            try {
                $image = New-Object System.Windows.Controls.Image
                $image.Width = 42
                $image.Height = 42
                $image.Margin = "0,0,11,0"
                $image.Stretch = "Uniform"
                $bitmap = New-Object System.Windows.Media.Imaging.BitmapImage
                $bitmap.BeginInit()
                $bitmap.CacheOption = "OnLoad"
                $bitmap.UriSource = New-Object System.Uri -ArgumentList $iconPath
                $bitmap.EndInit()
                $image.Source = $bitmap
                $gameHeader.Children.Add($image) | Out-Null
            } catch {}
        }

        $name = New-Object System.Windows.Controls.TextBlock
        $name.Text = [string]$game.Name
        $name.FontSize = 17
        $name.FontWeight = "SemiBold"
        $name.Foreground = "#F4F7FF"
        $name.TextTrimming = "CharacterEllipsis"
        $name.VerticalAlignment = "Center"
        $name.MaxWidth = 140
        $gameHeader.Children.Add($name) | Out-Null
        $cardContent.Children.Add($gameHeader) | Out-Null

        $buttonRow = New-Object System.Windows.Controls.StackPanel
        $buttonRow.Orientation = "Horizontal"
        $buttonRow.VerticalAlignment = "Bottom"
        [System.Windows.Controls.DockPanel]::SetDock($buttonRow, "Bottom")

        $launch = New-Object System.Windows.Controls.Button
        $launch.Content = "JOUER >"
        $launch.Tag = [string]$game.Path
        $launch.Width = 170
        $launch.Height = 34
        $launch.Foreground = "White"
        $launch.Background = "#00B894"
        $launch.BorderThickness = 0
        $launch.FontWeight = "Bold"
        $launch.Cursor = "Hand"
        $launch.Add_Click({
            param($sender, $eventArgs)
            $target = [string]$sender.Tag
            Start-Game $target
        })
        $buttonRow.Children.Add($launch) | Out-Null

        $remove = New-Object System.Windows.Controls.Button
        $remove.Content = "X"
        $remove.Tag = [string]$game.Path
        $remove.ToolTip = "Retirer ce jeu"
        $remove.Width = 30
        $remove.Height = 30
        $remove.Margin = "8,0,0,0"
        $remove.Foreground = "#FF7675"
        $remove.Background = "Transparent"
        $remove.BorderThickness = 0
        $remove.FontSize = 14
        $remove.Cursor = "Hand"
        $remove.Add_Click({
            param($sender, $eventArgs)
            $pathToRemove = [string]$sender.Tag
            $answer = [System.Windows.MessageBox]::Show(
                "Retirer ce jeu du launcher ?",
                "Game Launcher",
                "YesNo",
                "Question"
            )
            if ($answer -ne "Yes") { return }
            $remaining = @(Get-Games | Where-Object { [string]$_.Path -ne $pathToRemove })
            Save-Games $remaining
            Refresh-Games
        })
        $buttonRow.Children.Add($remove) | Out-Null
        $cardContent.Children.Add($buttonRow) | Out-Null
        $gamePanel.Children.Add($card) | Out-Null
    }
}

$addButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = "Choisissez le jeu ou son raccourci"
    $dialog.Filter = "Jeux et raccourcis (*.exe;*.lnk;*.url)|*.exe;*.lnk;*.url|Tous les fichiers (*.*)|*.*"
    $dialog.Multiselect = $false

    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $games = @(Get-Games)
        if ($games.Path -contains $dialog.FileName) {
            [System.Windows.MessageBox]::Show("Ce jeu est deja dans la liste.", "Game Launcher") | Out-Null
            return
        }

        $displayName = [System.IO.Path]::GetFileNameWithoutExtension($dialog.FileName)
        $games += [PSCustomObject]@{
            Name = $displayName
            Path = $dialog.FileName
        }
        Save-Games $games
        Refresh-Games
    }
})

$searchBox.Add_TextChanged({ Refresh-Games })

$performanceTimer = New-Object System.Windows.Threading.DispatcherTimer
$performanceTimer.Interval = [TimeSpan]::FromSeconds(4)
$performanceTimer.Add_Tick({ Optimize-RetracProcesses })
$performanceTimer.Start()

Update-FpsButton
Refresh-Games
$window.ShowDialog() | Out-Null
